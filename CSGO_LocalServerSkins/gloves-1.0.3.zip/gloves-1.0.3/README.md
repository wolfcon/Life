# Gloves for CS:GO Community Servers

--------------------

If you want to donate, I'd appreciate it:

https://steamcommunity.com/tradeoffer/new/?partner=37011238&token=yGo05pTn
